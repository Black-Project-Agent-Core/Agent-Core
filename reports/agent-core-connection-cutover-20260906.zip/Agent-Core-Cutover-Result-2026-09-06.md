# Agent Core: Hasil Penerapan Perbaikan Koneksi

Tanggal: 6 September 2026, Asia/Jakarta.
Status: **DEPLOYED_LOCAL_VERIFIED — perbaikan produksi lokal diterapkan dan lulus pemeriksaan; koneksi melalui dua chat ChatGPT belum disertifikasi.**

Dokumen ini melanjutkan laporan review dan repair sebelumnya. Pernyataan historis “kandidat belum diterapkan” benar untuk sesi sebelumnya, tetapi bukan lagi status instalasi saat hasil ini diterbitkan.

## 1. Hasil utama

Pengguna menutup Agent Code sepenuhnya dan meminta perbaikan dilanjutkan. Pemeriksaan langsung pada 03:06:08 WIB memastikan proses Agent Code, server Agent Core, serta tunnel tidak berjalan dan port 8765/8787 kosong. Persetujuan perbaikan sebelumnya tetap berlaku; tidak dilakukan pengambilalihan atau penghentian paksa proses.

Dalam kondisi offline tersebut, enam file source yang sudah ditinjau, tujuh tes regresi, dan 12 file build JavaScript/source-map diterapkan ke `E:\Projects\Agent-Core`. Penyimpanan autentikasi dan audit disalin ke generasi privat yang dapat ditulis/diganti oleh pengguna aktif, dengan pembuktian hash dan rantai audit sebelum pointer diaktifkan. Setelah itu, satu pembatas pemindaian tes dan satu tes regresi tambahan ditambahkan untuk mencegah salinan source di folder laporan dieksekusi sebagai tes aplikasi.

Aplikasi native yang sudah ada dibuka kembali. Server, tunnel, memory dan execution berhasil berjalan; kesehatan keseluruhan berubah dari `degraded` menjadi `healthy`. Audit berhasil melakukan rotasi dan kembali mencatat event baru tanpa `EPERM` selama pengamatan.

## 2. Perubahan yang benar-benar diterapkan

| Area | Implementasi |
|---|---|
| `src/oauth/store.ts`, `src/oauth/service.ts` | Antrean operasi file dan pertukaran grant/token dalam satu snapshot, menghindari lost update dan konsumsi ganda. |
| `src/oauth/file-lock.ts` | Koordinasi lintas proses melalui lock SQLite tanpa payload credential atau memori. |
| `src/oauth/atomic-file.ts` | Snapshot sementara disinkronkan lalu diganti dengan rename; kegagalan rename tidak dilanjutkan dengan overwrite credential lama. |
| `src/runtime/persistence-paths.ts`, `src/config.ts` | Pemilihan generasi persistence yang valid melalui manifest, termasuk kompatibilitas dengan path bawaan launcher lama. |
| `vitest.config.ts` | Mengecualikan `**/reports/**` dari penemuan tes, tanpa mengecualikan tes aplikasi di `tests/`. |
| `tests/` | Tujuh regresi dari kandidat, ditambah `report-discovery-cutover.test.ts`. |

Source dan build tidak disalin secara menyeluruh dari worktree. File lain milik pekerjaan paralel dipertahankan. Binary native tidak dibangun ulang atau diganti. Tidak ada commit atau push Git pada pekerjaan ini; bukti deployment ditambatkan pada hash file dan laporan pengujian, bukan klaim bahwa seluruh working tree bersih.

## 3. Penyimpanan aktif dan perlindungan data

Proyek dan launcher utama tetap berada pada lokasi yang sama:

```text
E:\Projects\Agent-Core
E:\Projects\Agent-Core\SubProject\Agent-Code\Agent Code Native.exe
```

Lokasi penyimpanan aktif yang dipilih:

```text
runtime\persistence-20260906\data
runtime\persistence-20260906\logs
```

Pointer pemilihan:

```text
runtime\persistence.json
schemaVersion: 1
generation: 20260906
```

Direktori generasi diverifikasi dimiliki pengguna aktif dengan ACL privat yang hanya memberikan akses kepada pengguna tersebut, SYSTEM, dan Administrators. ACL atau pemilik file lama tidak diambil alih atau diubah.

`keys.json` dan `oauth.json` identik secara byte saat penyalinan. Seluruh file log yang disalin juga diperiksa hash-nya. Lokasi sumber lama tetap ada; tidak ada reset OAuth, pencabutan grant, pembuatan API key pengganti, atau pemindahan database memory/execution. File `.env` dan profil tunnel tidak diubah.

Canary lokal memakai API key terdaftar hanya untuk permintaan ke loopback. Nilainya tidak dicetak, diekspor atau dimasukkan ke laporan. Pembaruan normal `lastUsedAt` pada metadata key dikecualikan dari pemeriksaan identitas; seluruh identitas key lainnya tetap sama. File OAuth juga tidak berubah selama canary tersebut.

## 4. Bukti pemulihan audit

Sebelum penerapan, rantai audit yang tersedia berisi sequence 1–28.608. Head hash-nya adalah:

```text
cb2087b1b54ac7b565acdb9ad41280d9a1be7c5cde37f46fdeca5bd59cc357fe
```

Penyalinan ke generasi baru mempertahankan seluruh 28.608 record dan head hash yang sama. Sesudah startup, rotasi pertama berhasil. Berkas arsip hasil rotasi identik secara byte dengan berkas audit aktif lama. Event baru pertama memiliki sequence **28.609** dan menunjuk head lama sebagai `previousHash`.

Pada akhir canary, verifier melaporkan rantai valid dari sequence 1 sampai **28.681**, sebanyak 28.681 record dalam dua file. Selama 16 sampel kesehatan canary, `audit.writeErrors` selalu **0**, rotasi berjumlah **1**, dan penulisan baru terus bertambah. Ini merupakan bukti bahwa pencatatan kembali bekerja, bukan sekadar penghitung error yang kembali nol setelah restart.

**Gap pencatatan sebelum perbaikan tidak direkonstruksi.** Rantai tersimpan yang valid tidak berarti event yang gagal dicatat pada interval sebelumnya telah dipulihkan. Tidak dibuat event historis palsu untuk menutupi gap tersebut.

## 5. Pengujian sebelum dan setelah deployment

| Gate | Hasil |
|---|---|
| Kecocokan hash baseline produksi dan 13 file kandidat | PASS sebelum penerapan. |
| Pengujian ulang kandidat lengkap | 71/71 PASS. |
| Build kandidat | PASS. |
| Typecheck source produksi setelah penerapan | PASS. |
| Kesamaan snapshot autentikasi dan integritas audit sebelum startup | PASS. |
| Regresi penemuan tes sebelum perubahan konfigurasi | 1 FAIL yang diharapkan. |
| Pengujian akhir instalasi utama | **73/73 PASS, 15 file tes, 0 file gagal.** |
| Startup melalui binary native yang sudah ada | PASS. |
| Canary MCP lokal pada server produksi | PASS. |
| Dua percakapan ChatGPT nyata dan soak jangka panjang | BELUM diuji/disertifikasi. |

Pengujian pertama dari root sempat exit 1 walaupun assertion yang berjalan lulus. Penyebabnya adalah runner ikut menemukan salinan tes dalam `reports/connection-review-20260906/tests` dan `reports/connection-repair-20260906/candidate-files/tests`; lima suite salinan tidak mempunyai dependency relatif yang lengkap. Bukti kegagalan itu dipertahankan di `deployed-tests.json`. Perbaikan berupa pembatas penemuan artefak laporan diuji RED/GREEN; assertion aplikasi tidak dihapus atau dilonggarkan.

Pengujian terfokus ini bukan klaim bahwa seluruh suite repository atau seluruh subproyek telah disertifikasi ulang.

## 6. Pemeriksaan runtime yang sebenarnya

Launcher native dibuka kembali pada sekitar **03:13 WIB**. Identitas proses pada startup tercatat sebagai native PID 21768, server PID 20172, dan tunnel PID 7584. PID bersifat historis; sesi berikutnya harus memeriksa ulang, bukan menghentikan proses berdasarkan angka tersebut.

Canary berlangsung **03:14:51–03:15:26 WIB**, sekitar 35 detik. Dua klien SDK independen memakai protokol legacy dan modern. Sebanyak **14 pemanggilan status** berhasil; penutupan satu klien tidak mematikan klien lain, dan klien baru dapat terhubung kembali. Endpoint produksi mengembalikan **69 alat**, termasuk `subagentcore`.

Permintaan tanpa autentikasi sengaja diuji dan ditolak dengan HTTP 401. Respons tersebut adalah hasil negatif yang diharapkan, bukan insiden login baru. Canary tidak membuat grant OAuth baru atau memanggil provider model eksternal.

Semua 16 sampel kesehatan pada canary menunjukkan `overallHealth: healthy`, memory sehat, execution sehat, dan tidak ada error tulis audit. Ini adalah canary singkat, bukan jaminan uptime tanpa batas.

## 7. Batas yang masih berada di sisi ChatGPT

Pencarian katalog menunjukkan satu Agent Core terpasang. Namun, discovery namespace `Agent_Core` pada pesan ini tidak menyediakan fungsi, baik sebelum maupun setelah server dibuka kembali. Karena itu, **tidak ada klaim bahwa pemanggilan melalui konektor ChatGPT telah berhasil pada pesan ini**. Keberhasilan canary lokal tidak disamakan dengan keberhasilan dua chat nyata.

Pesan `FORBIDDEN: This conversation does not support developer MCPs` adalah observasi sesi sebelumnya. Pada pesan sekarang observasinya adalah namespace tidak diekspos; keduanya tidak boleh dicampur menjadi satu error yang diklaim baru terjadi.

Dokumentasi OpenAI menyatakan pemilihan app berlaku untuk pesan tempat app dipilih, bukan otomatis seluruh percakapan; pemanggilan baru dapat memerlukan penyebutan app lagi. Dokumentasi juga menjelaskan bahwa pembaruan tool server tidak selalu memperbarui daftar action host secara otomatis. Fakta umum tersebut membantu pemeriksaan, tetapi tidak membuktikan seluruh kejadian historis pengguna berasal dari satu penyebab.

Tool pengelolaan yang tersedia tidak menyediakan penyegaran manifest action developer MCP. Tidak dilakukan penghapusan/pemasangan ulang plugin, pelemahan izin global, atau perubahan autentikasi sebagai percobaan.

Uji akhir yang masih diperlukan: chat baru dengan Agent Core dipilih secara eksplisit, kemudian pengujian panggilan berulang dan lintas dua chat sambil mengamati audit yang sekarang sudah sehat.

## 8. Artefak, handoff dan rollback

Folder hasil:

```text
E:\Projects\Agent-Core\reports\connection-cutover-20260906
```

Bukti utama: `offline-preflight.json`, `offline-deployment.json`, `full-candidate-retest.json`, `deployed-tests.json`, `discovery-red.json`, `deployed-green-tests.json`, `native-start.json`, `first-live-health.json`, dan `live-canary.json`. Source/build sebelum penerapan disimpan dalam `preapply-source-backup`. Script `offline-cutover.py` memiliki pemeriksaan offline dan penolakan penerapan ulang; ia bukan script yang perlu dijalankan setiap membuka aplikasi.

Panduan terbaru berada pada `docs/agent-core-connection-troubleshooting.md`; versi sebelum pembaruan dipertahankan. Laporan review/repair lama tidak ditimpa. Checkpoint DMF tidak diperbarui melalui konektor pada pesan ini karena tool Agent Core tidak diekspos; handoff yang berhasil disimpan adalah file laporan dan panduan.

**Jangan menghapus `runtime/persistence.json` atau kembali memakai snapshot autentikasi lama setelah generasi aktif menerima aktivitas baru.** Rollback harus mempertahankan state autentikasi aktif terbaru. Backup source bukan izin mengembalikan credential ke masa lalu. Jangan commit seluruh worktree overlay atau menyalin ulang seluruh `src/dist`.

## 9. Referensi

Bukti instalasi berasal dari source dan artefak pengujian lokal yang disebutkan di atas. Sumber web hanya dipakai untuk perilaku host umum, bukan untuk menetapkan status PC pengguna.

OpenAI, Developer mode and MCP apps in ChatGPT, diperiksa 6 September 2026:
https://help.openai.com/en/articles/12584461

**Kesimpulan: perbaikan produksi lokal sudah diterapkan dan berjalan sehat pada pengujian. Sertifikasi konektor lintas chat ChatGPT masih menunggu pengujian host.**

## 10. Catatan verifikasi setelah canary

Pada pemeriksaan berikutnya, PID server berubah dari 20172 menjadi 10292 dan PID tunnel menjadi 9608, sementara aplikasi native tetap PID 21768. Proses pemicu pergantian tersebut tidak lagi tersedia untuk diperiksa; penyebab restart ini tidak ditetapkan. Jangan menganggapnya sebagai restart kedua yang sengaja dilakukan oleh script cutover.

Penghitung `audit.written` adalah penghitung per proses, sehingga pemeriksaan awal yang menuntut nilainya selalu lebih besar dari 72 memberikan alarm yang keliru setelah pergantian proses. Bukti lanjutan pada 03:22:27 WIB menunjukkan sequence persisten bertambah dari 28.731 menjadi 28.732, error tulis tetap 0, dan kesehatan keseluruhan healthy. Pemeriksaan kemajuan lintas restart harus memakai sequence persisten, bukan membandingkan penghitung per proses tanpa identitas proses. Observasi ini disimpan dalam `post-canary-process-observation.json`; belum ada klaim tentang penyebab pergantian proses.
