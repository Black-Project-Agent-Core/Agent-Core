# Codespace Supervisor — ChatGPT Action Only

This version does **not** use Codex CLI, Codex Desktop, an OpenAI API key, or an external AI coding worker.

The reasoning loop stays in the Custom GPT conversation:

```text
ChatGPT web
  -> GPT Action
  -> Hardened bridge in the exact Codespace
  -> read/write files, Git, tests/builds
  -> results back to ChatGPT
  -> ChatGPT decides the next tool call
```

Long builds/tests use a non-AI command job. The job only runs the exact command ChatGPT requested and returns logs/status.

## 1. Install bridge outside the repo

```bash
mkdir -p ~/.codespace-supervisor
cd ~/.codespace-supervisor
python3 -m venv .venv
. .venv/bin/activate
```

Copy `server.py` and `requirements.txt` here, then:

```bash
pip install -r requirements.txt
```

## 2. Configure one exact Codespace workspace

```bash
export WORKSPACE_ROOT="/workspaces/Market-Signal-Lab"
export BRIDGE_HOME="$HOME/.codespace-supervisor"
export BRIDGE_TOKEN="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
export PROTECTED_BRANCHES="main,master"
```

Save `BRIDGE_TOKEN` in a password manager. Do not use a GitHub PAT as the bridge token.

## 3. Start bridge

```bash
cd ~/.codespace-supervisor
. .venv/bin/activate
uvicorn server:app --host 0.0.0.0 --port 8787
```

Local test:

```bash
curl -sS   -H "Authorization: Bearer $BRIDGE_TOKEN"   http://127.0.0.1:8787/health
```

Expected `mode`:

```json
"mode": "chatgpt-action-only"
```

## 4. Expose port to GPT Action

In VS Code Codespaces -> Ports, expose port `8787` so ChatGPT can reach it.

Copy the forwarded HTTPS URL and replace this placeholder in `action-openapi.yaml`:

```text
https://REPLACE-WITH-YOUR-CODESPACE-8787.app.github.dev
```

## 5. Configure GPT Action

In GPT Builder:

- Add Action
- Authentication: API Key
- Type: Bearer
- Secret: `BRIDGE_TOKEN`
- Schema: paste `action-openapi.yaml`

Paste `gpt-action-instructions.md` into the GPT instructions, keeping the total under the Builder character limit.

## 6. Smoke test

Use this order:

1. `Cek koneksi ke Codespace ini dan jangan hanya menjawab; gunakan Action.`
2. `Tampilkan branch dan git status.`
3. `Buat branch baru cs-supervisor/smoke-test.`
4. `Baca README.md.`
5. `Tambahkan satu perubahan dokumentasi kecil yang aman.`
6. `Tampilkan git diff.`
7. `Jalankan test singkat yang relevan.`

For a longer command:

> Jalankan build ini lewat command job, berikan jobId, poll sampai selesai, lalu analisis outputnya.

## Important limitation

This gives ChatGPT itself real tool access during an active ChatGPT turn. It does not turn a Custom GPT Action into a persistent AI daemon after the turn ends.

The included `/jobs/command` endpoint can keep a build/test subprocess running and return a `jobId`, but the bridge does not contain another AI model. ChatGPT must still be active to inspect the result and decide the next coding step.

## Two projects

Use one fixed bridge/token per Codespace:

```text
Project A -> Codespace A -> bridge/token A
Project B -> Codespace B -> bridge/token B
```

Do not use a dynamic repository-switch endpoint.
