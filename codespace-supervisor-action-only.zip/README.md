# Codespace Supervisor — Action-only package

This is the version aligned with the original goal:

**ChatGPT web itself performs the coding loop through GPT Actions. No Codex worker is used by default.**

Files:
- `server.py`
- `requirements.txt`
- `action-openapi.yaml`
- `gpt-action-instructions.md`
- `SETUP.md`

Start with `SETUP.md`.
